Introduction:
Welcome to the team-based software development course! In this course, you will have the opportunity to work on various real-world projects to enhance your skills and knowledge in software development. Each group will be assigned a specific project to work on, and you will collaborate with your team members to create a functional and innovative application. Let's take a look at the projects for each group:

Projects:

- Group A: Real State App
- Group B: StroySharing App
- Group C: eLearning App
- Group D: eCommerce App
- Group E: Budget Tracking App
- Group F: Personal Dashboard App

- **Group A: Real State App**

  - Eng Omar (Coordinator)
  - Xaydar (Leader)
  - Najax
  - Abdirahim
  - Zakaria Abdiulahi

- **Group B: StroySharing App**

  - Sharfdiin (Coordinator)
  - Afi (Leader)
  - Anisa
  - Ishaq
  - Liban

- **Group C: eLearning App**

  - Abdinasir (Coordinator)
  - Mustafa (Leader)
  - Aisha
  - Ahmed Nur
  - Ahmed Hersi

- **Group D: eCommerce App**

  - Omar (Coordinator)
  - Usama (Leader)
  - Faysal
  - MahAemd Ar
  - Kalid
  - Mohamed Ahmed

- **Group E: Budget Tracking App**

  - Sharafdiin (Coordinator)
  - Zakaria (Leader)
  - Mohamud
  - Abrisaq
  - Abdullahi Nadiif

- **Group F: Personal Dashboard App**
  - Abdinasir (Coordinator)
  - Mohamed Abdulkadir (Leader)
  - Abdullahi Hassan
  - Abdullahi Qaska Haji
  - Abdirahman Abdirizak
